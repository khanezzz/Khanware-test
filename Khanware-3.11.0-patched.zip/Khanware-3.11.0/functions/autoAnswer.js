// Patched Auto Answers: do not blindly click answer choices.
// The previous implementation repeatedly clicked every matching selector,
// which could repeatedly select the first choice (often A) on current pages.
// AI solving remains in questionSpoof.js and is triggered when assessment
// items are fetched; submitting an answer lets that module apply a solved map.

let khanwareAutoAnswerLoopStarted = false;

if (!khanwareAutoAnswerLoopStarted) {
    khanwareAutoAnswerLoopStarted = true;
    (async () => {
        let lastNotice = 0;
        while (true) {
            try {
                if (features?.autoAnswer && features?.questionSpoof) {
                    // Never click answer choices blindly. Only proceed when the
                    // page explicitly exposes a next/continue control after completion.
                    const nextSelectors = [
                        '[data-testid="exercise-next-question"]',
                        '._g9riz5o',
                        '._1kkrg8oi'
                    ];
                    const completedText = /^(next|continue|next question|próximo|continuar|siguiente|continuar)$/i;
                    const pageText = (document.body?.innerText || '').slice(-3000);
                    const looksCompleted = /exercise complete|exercício concluído|ejercicio completado|you've completed/i.test(pageText);
                    if (looksCompleted && features.nextRecomendation) {
                        for (const selector of nextSelectors) {
                            const el = document.querySelector(selector);
                            if (el && !el.disabled && el.offsetParent !== null) {
                                const label = (el.innerText || el.getAttribute('aria-label') || '').trim();
                                if (!label || completedText.test(label)) {
                                    el.click();
                                    break;
                                }
                            }
                        }
                    }
                    if (Date.now() - lastNotice > 15000) {
                        if (typeof sendToast === 'function') {
                            sendToast('Auto Answers: đã chặn thao tác bấm đáp án lặp. AI solver nằm trong questionSpoof.js.', 3500, 'top');
                        }
                        lastNotice = Date.now();
                    }
                }
            } catch (e) {
                console.warn('[Khanware patched Auto Answers]', e);
            }
            await delay(1200);
        }
    })();
}
